Progetto (personale) sul trattamento informatico di immagini nel contesto del daltonismo

Contenuto:
pdf per la visualizzazione rapida
notebook ipynb
immagini (non ho usato una cartella images per evitare problemi di porting tra colab/jupyter/vscode)

NOTA:
Nel notebook ho spostato la parte su Selenium per ultima onda evitare problemi nel caso di esecuzione su ambiente locale (i comandi sono per Google Colab), trattasi comunque di una parte extra.